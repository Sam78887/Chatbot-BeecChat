import React, { createContext, useState, useContext } from 'react';

// Create a Context for the theme
const ThemeContext = createContext();

// Custom hook for using the ThemeContext
export const useTheme = () => useContext(ThemeContext);

// Theme Provider component
export const ThemeProvider = ({ children }) => {
    // Define theme colors and properties for light and dark modes
    const lightTheme = {
        backgroundColor: '#ffffff',
        color: '#000000', // Default text color
        firstRowTextColor: '#000000' // Black color for first row text
    };

    const darkTheme = {
        backgroundColor: '#333333',
        color: '#add8e6', // Light blue color for general text
        firstRowTextColor: '#000000' // Black color for first row text (can be changed as needed)
    };

    const [theme, setTheme] = useState(lightTheme); // Default theme is light

    // Function to toggle between light and dark themes
    const toggleTheme = () => {
        setTheme((prevTheme) => 
            prevTheme === lightTheme ? darkTheme : lightTheme
        );
    };

    return (
        <ThemeContext.Provider value={{ theme, toggleTheme }}>
            {children}
        </ThemeContext.Provider>
    );
};