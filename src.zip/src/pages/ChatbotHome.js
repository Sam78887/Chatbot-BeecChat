import React, { useState } from 'react';
import './ChatbotHome.css';

const ChatbotHome = () => {
  const [message, setMessage] = useState('');
  const [output, setOutput] = useState('');
  const [history, setHistory] = useState([]);
  const [showHistory, setShowHistory] = useState(false);

  const handleSendMessage = async () => {
    if (message.trim()) {
      try {
        const response = await fetch('http://localhost:5000/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ message }),
        });

        const data = await response.json();
        const newOutput = data.response || 'No response';

        setOutput(newOutput);
        setHistory([...history, { message, output: newOutput }]);
        setMessage('');
      } catch (error) {
        console.error('Error:', error);
        setOutput('Error connecting to the chatbot.');
      }
    }
  };

  const toggleHistory = () => {
    setShowHistory(!showHistory);
  };

  return (
    <div className="chatbot-container">
      <h1 className="chatbot-title">Chatbot Interface</h1>
      
      <div className="input-output-box">
        <textarea
          className="message-box"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Enter your message"
        />
        <button className="send-btn" onClick={handleSendMessage}>Send</button>
        <div className="output-box">{output}</div>
      </div>

      <button className="history-btn" onClick={toggleHistory}>
        {showHistory ? 'Hide History' : 'Show History'}
      </button>
      
      {showHistory && (
        <div className="history-box">
          {history.map((entry, index) => (
            <div key={index} className="history-entry">
              <p><strong>Message:</strong> {entry.message}</p>
              <p><strong>Output:</strong> {entry.output}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ChatbotHome;
