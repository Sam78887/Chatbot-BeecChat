import React from 'react';
import './SimpleHome.css';
import { useTheme } from '../ThemeContext'; // Import the theme hook
import ChatbotHome from "/Users/samareshdutta/Desktop/chatbotv11 react exp latest/src/pages/ChatbotHome.js";

const SimpleHome = () => {
  const { theme } = useTheme(); // Access the current theme ('light' or 'dark')

  return (
    <div className={`home-container ${theme}`}> {/* Apply the theme class */}
      
      <h2>BeeChat-Chatbot</h2>

      {/* Investment Options Section */}

      <br />
      <div className="horizontal-line"></div>
      <br />
      <ChatbotHome/>
      {/* Suggested Investment Comparison Section */}

      <br />
      <div className="horizontal-line"></div>
      <br />

      {/* Personalized Investment Section */}

      
      <div className="horizontal-line"></div>
      
    </div>
  );
};

export default SimpleHome;