import React, { useState } from 'react';
import './LoginPage.css'; // Import specific CSS for the login page

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle login logic here
    console.log('Login submitted:', { email, password });
  };

  return (
    

    <div className="login-container">
      <h1>WELCOME</h1>
      <h2>Login to InvestIQ Account</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="email">Email : </label>
        <input
          type="email"
          id="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <label htmlFor="password">Password : </label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <div className='ttt'>
        <button type="submit">Login</button>
        </div>

      </form>
    </div>
  );
};

export default LoginPage;