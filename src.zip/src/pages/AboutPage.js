import React from 'react';
import './AboutPage.css'; // Import specific CSS for the About page

const AboutPage = () => {
  return (
    <div className="about-container">
      <h1>About InvestIQ</h1>
      <p>
        InvestIQ is a leading platform for investment comparison and suggestions. We provide users with 
        tools to explore various investment options, compare them, and make informed decisions based on 
        personalized recommendations.
      </p><br></br><br></br>
      <p>
        Our goal is to empower investors with the information and insights they need to make sound financial 
        decisions. Whether you're looking to invest in stocks, real estate, or government bonds, InvestIQ 
        offers comprehensive analysis and comparisons to help you achieve your financial goals.
      </p>
    </div>
  );
};

export default AboutPage;