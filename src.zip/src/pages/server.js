const express = require('express');
const { exec } = require('child_process');

const app = express();
app.use(express.json());

app.post('/chat', (req, res) => {
  const userMessage = req.body.message;
  const pythonProcess = exec(`python3 chatbot.py "${userMessage}"`, (error, stdout, stderr) => {
    if (error) {
      console.error(`exec error: ${error}`);
      res.status(500).send("Error occurred while running chatbot");
      return;
    }
    if (stderr) {
      console.error(`stderr: ${stderr}`);
    }
    res.json(JSON.parse(stdout));
  });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});