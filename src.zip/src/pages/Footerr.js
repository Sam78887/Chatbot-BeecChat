import React from "react";
import { Outlet, Link } from "react-router-dom";

import './Footerr.css'; // Assuming you have a separate CSS file for styles
<meta name="viewport" content="width=device-width, initial-scale=1.0"></meta>
const Footerr = () => {
    
  return (
    <>
    <div className="f1">


        @InvestIQ All Rights Reserved
        <br /><br /><br /><br /><br /><br />
            <p>
            Contact Us: 
- Email: support@InvestIQ.com 
- Phone: +123 456 7890
</p>
<p>
Follow Us:
- Facebook | Twitter | Instagram | LinkedIn
</p>
<p>
Address:
1234 Street Name, Kolkata, India
</p>
<p>
Privacy Policy | Terms of Service | Cookie Policy</p>

    </div>
    
    <Outlet />
    </>
  );
};
export default Footerr;