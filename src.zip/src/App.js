import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider, useTheme } from "./ThemeContext"; // Import the theme context

import Navbar from "./pages/Navbar";
import SimpleHome from "./pages/SimpleHome";
import LoginPage from "./pages/LoginPage";
import AboutPage from "./pages/AboutPage";
import ContactPage from "./pages/ContactPage";
import NoPage from "./pages/NoPage";
import Footerr from "./pages/Footerr";
import ChatbotHome from "/Users/samareshdutta/Desktop/chatbotv11 react exp latest/src/pages/ChatbotHome.js";
function AppContent() {
  const { theme } = useTheme(); // Use the theme from context

  return (
    <div className={`App ${theme}`}> {/* Apply the theme class */}
    
      <Navbar />
      <Routes>
        <Route index element={<SimpleHome />} />
        <Route path="AboutPage" element={<AboutPage />} />
        <Route path="ContactPage" element={<ContactPage />} />
        <Route path="LoginPage" element={<LoginPage />} />
        <Route path="*" element={<NoPage />} />
      </Routes>
      <Footerr />
    </div>
  );
}

function App() {
  return (
    <ThemeProvider> {/* Wrap the app with the ThemeProvider */}
      <BrowserRouter>
      
        <AppContent />
      </BrowserRouter>
    </ThemeProvider>
  );
}

export default App;
